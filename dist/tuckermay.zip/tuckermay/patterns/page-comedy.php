<?php
/**
 * Title: Comedy Ghostwriting page
 * Slug: tuckermay/page-comedy
 * Categories: tuckermay-pages
 * Description: Packages (single sheet and retainers), credentials, rotating sample jokes, sample sheets, FAQ, and contact form.
 * Block Types: core/post-content
 * Post Types: page
 * Viewport width: 1400
 *
 * @package tuckermay
 */
?>
<!-- wp:group {"className":"tm-page"} -->
<div class="wp-block-group tm-page"><!-- wp:group {"className":"tm-hero"} -->
<div class="wp-block-group tm-hero"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">For podcasts and YouTube channels</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Comedy Ghostwriting</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-lede"} -->
<p class="tm-lede">I write killer jokes for podcasts and YouTube channels looking to increase engagement through humor. Tell me what your episode or video covers, and you’ll get a page of custom jokes and ad throws to pepper into your script in the way that’s most organic to your show.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"tm-btn-slate"} -->
<div class="wp-block-button tm-btn-slate"><a class="wp-block-button__link wp-element-button" href="#packages">See packages</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#samples">See samples</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-hire"} -->
<div class="wp-block-group tm-hire"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">Why hire me</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Trained on the same stages as late night’s best</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"tm-hire-grid"} -->
<div class="wp-block-group tm-hire-grid"><!-- wp:group -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"tm-hire-big"} -->
<p class="tm-hire-big">Mee-Ow</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Alum of Northwestern’s storied sketch group. Fellow alums include Seth Meyers, Kristen Schaal, and Julia Louis-Dreyfus.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"tm-hire-big"} -->
<p class="tm-hire-big">Second City &amp; iO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Has written for comedy teams at The Second City, iO, and iO West.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"tm-hire-big"} -->
<p class="tm-hire-big">Late-night jokes</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Trained in late-night joke writing at The Second City and The Comedy Lab.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"packages"} -->
<div id="packages" class="wp-block-group"><!-- wp:group {"className":"tm-section-head"} -->
<div class="wp-block-group tm-section-head"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">Packages</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Try one, or keep the jokes coming</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-lede"} -->
<p class="tm-lede">Every one-sheet: 10 punch-up jokes and 5 intros, transitions, or ad throws, written for your episode or video.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-pks"} -->
<div class="wp-block-group tm-pks"><!-- wp:group {"className":"tm-pk tm-pk--trial"} -->
<div class="wp-block-group tm-pk tm-pk--trial"><!-- wp:paragraph {"className":"tm-pk-badge"} -->
<p class="tm-pk-badge">Risk-free trial</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Single one-sheet</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-pk-price"} -->
<p class="tm-pk-price">$250</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-pk-per"} -->
<p class="tm-pk-per">one-time</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"tm-checks"} -->
<ul class="wp-block-list tm-checks"><!-- wp:list-item -->
<li>10 punch-up jokes</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>5 customized intros, transitions, or ad throws</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Delivered within 5 days</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>First order? Money back if you don’t use a single joke</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://www.paypal.com/ncp/payment/ZWBQS9N9BLE6G" target="_blank" rel="noreferrer noopener">Buy now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-pk"} -->
<div class="wp-block-group tm-pk"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Bi-Weekly Retainer</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-pk-price"} -->
<p class="tm-pk-price">$450</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-pk-per"} -->
<p class="tm-pk-per">per month · $225 per sheet</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"tm-checks"} -->
<ul class="wp-block-list tm-checks"><!-- wp:list-item -->
<li>2 one-sheets per month</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Topics of your choice</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>3-day speedy delivery</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Cancel anytime</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://www.paypal.com/ncp/payment/JTAVSWRCAD25U" target="_blank" rel="noreferrer noopener">Buy now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-pk tm-pk--best"} -->
<div class="wp-block-group tm-pk tm-pk--best"><!-- wp:paragraph {"className":"tm-pk-badge"} -->
<p class="tm-pk-badge">Best deal</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Monthly Retainer</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-pk-price"} -->
<p class="tm-pk-price">$850</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-pk-per"} -->
<p class="tm-pk-per">per month · $212.50 per sheet</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"tm-checks"} -->
<ul class="wp-block-list tm-checks"><!-- wp:list-item -->
<li>4 one-sheets per month</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Topics of your choice</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>3-day speedy delivery</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Lowest price per sheet</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Cancel anytime</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://www.paypal.com/ncp/payment/VZH39TD9YFLHA" target="_blank" rel="noreferrer noopener">Buy now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:group {"className":"tm-section-head"} -->
<div class="wp-block-group tm-section-head"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">A taste</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Lines from real one-sheets</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-lede"} -->
<p class="tm-lede">A few favorites from the sample sheets. They change every few seconds.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-jokes tm-rotator"} -->
<div class="wp-block-group tm-jokes tm-rotator"><!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">In this movie, a man risks everything to save a rock. In Kevin Hart movies, a man risks everything to save The Rock.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Project Hail Mary</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The severance procedure is messed up. The only time you shouldn’t remember what happened at work is the day after the office Christmas party.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Severance</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The salaries for the movie’s stars leaked online. The original was based on a book. The sequel is based on a checkbook.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The Devil Wears Prada 2</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The show is called The White Lotus and the creator is Mike White. I guess he felt “The Mike Lotus” was too on-the-nose.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The White Lotus</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Jordan Peele’s production company lost a bidding war for Weapons. He said, “Us?” and they said, “Nope. Get Out.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Weapons</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Adam Scott’s character defends his work at Lumon as “mysterious and important,” which is the exact phrase I use to describe my cat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Severance</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">I thought Gosling made a pretty convincing astronaut. Others say his performance lacks gravity.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Project Hail Mary</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Season four is reportedly set in France. It’s titled, The White Lotus: Oops! All Mimes.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The White Lotus</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The sequel’s romantic subplot is so undercooked it might give you salmonella.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The Devil Wears Prada 2</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Director Zach Cregger had a history in sketch comedy before turning to horror films. What a pivot: from doing sketch to being sketch.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Weapons</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Rocky survives a lot in this movie. He beats scissors but ultimately succumbs to paper.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Project Hail Mary</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Some fans are upset it took 20 years for a sequel. At this rate, the third’ll be called “The Devil Is Buried in Prada.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The Devil Wears Prada 2</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The characters in the show are working on a way to undo severance, effectively reversing a surgical procedure. I’m way ahead of them. I put my appendix back in years ago.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Severance</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">The script for Weapons sold for $38 million, which is only slightly more than I paid for the ticket to see it.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">Weapons</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-joke"} -->
<div class="wp-block-group tm-joke"><!-- wp:paragraph {"className":"tm-joke-text"} -->
<p class="tm-joke-text">Mike White made the show as a COVID project and got a global hit. My COVID project was a sourdough starter that triggered my carbon monoxide detector.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"tm-joke-src"} -->
<p class="tm-joke-src">The White Lotus</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline tm-rot-next"} -->
<div class="wp-block-button is-style-outline tm-rot-next"><a class="wp-block-button__link wp-element-button" href="#">Show me more →</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"samples"} -->
<div id="samples" class="wp-block-group"><!-- wp:group {"className":"tm-section-head"} -->
<div class="wp-block-group tm-section-head"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">Samples</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">See full one-sheets</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-lede"} -->
<p class="tm-lede">Click any sheet to see it full size.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-sheets"} -->
<div class="wp-block-group tm-sheets"><!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/sample-the-white-lotus.jpg' ) ); ?>" alt="Comedy one-sheet for The White Lotus"/><figcaption class="wp-element-caption">The White Lotus</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/sample-severance.jpg' ) ); ?>" alt="Comedy one-sheet for Severance"/><figcaption class="wp-element-caption">Severance</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/sample-project-hail-mary.jpg' ) ); ?>" alt="Comedy one-sheet for Project Hail Mary"/><figcaption class="wp-element-caption">Project Hail Mary</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/sample-the-devil-wears-prada-2.jpg' ) ); ?>" alt="Comedy one-sheet for The Devil Wears Prada 2"/><figcaption class="wp-element-caption">The Devil Wears Prada 2</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":true},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/sample-weapons.jpg' ) ); ?>" alt="Comedy one-sheet for Weapons"/><figcaption class="wp-element-caption">Weapons</figcaption></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-panel tm-narrow"} -->
<div class="wp-block-group tm-panel tm-narrow"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">Why humor matters</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Funny keeps people watching and listening</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"tm-lede"} -->
<p class="tm-lede">A laugh early in an episode or video gives your audience a reason to stay, and a reason to come back next week. Your show already has the opinions and the expertise. A one-sheet adds the punchlines.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:group {"className":"tm-section-head"} -->
<div class="wp-block-group tm-section-head"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">How it works</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Three steps</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:list {"ordered":true,"className":"tm-steps"} -->
<ol class="wp-block-list tm-steps"><!-- wp:list-item -->
<li>Choose a package and check out through PayPal.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>At checkout, tell me what your episode or video covers, or any other topic you want jokes about. Retainer clients list each month’s topics when they pay that month’s invoice.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Get your one-sheet: within 5 days for a single sheet, within 3 days on a retainer.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:group {"className":"tm-section-head"} -->
<div class="wp-block-group tm-section-head"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">FAQ</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Questions</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-faqs"} -->
<div class="wp-block-group tm-faqs"><!-- wp:details {"className":"tm-faq"} -->
<details class="wp-block-details tm-faq"><summary>How long will it take?</summary><!-- wp:paragraph -->
<p>Single one-sheets arrive within 5 days of your order. Retainer sheets arrive within 3 days.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"tm-faq"} -->
<details class="wp-block-details tm-faq"><summary>What kind of jokes will it be?</summary><!-- wp:paragraph -->
<p>Each one-sheet has 10 one- or two-liner jokes, the kind you might hear in a late-night show monologue, plus 5 introductions, transitions, or ad throws customized for your show. It works the same way for podcast episodes and YouTube videos.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"tm-faq"} -->
<details class="wp-block-details tm-faq"><summary>Would you be willing to write jokes about topics other than TV shows and movies?</summary><!-- wp:paragraph -->
<p>Yes, absolutely. You can include the subject you’d like jokes about when placing your order.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"tm-faq"} -->
<details class="wp-block-details tm-faq"><summary>What about refunds?</summary><!-- wp:paragraph -->
<p>Your first one-sheet is a risk-free trial: if you don’t use any of the jokes in your episode or video, you get your money back. After your first order, one-sheets aren’t refundable. Retainers can be canceled anytime, but payments already made aren’t refunded.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"tm-faq"} -->
<details class="wp-block-details tm-faq"><summary>Do I need to credit you?</summary><!-- wp:paragraph -->
<p>You will own and retain all rights to the jokes. You are not required to credit me as a writer, but if you would like to do so it is highly appreciated.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"tm-panel"} -->
<div class="wp-block-group tm-panel"><!-- wp:paragraph {"className":"tm-eyebrow"} -->
<p class="tm-eyebrow">Questions?</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact Tucker</h2>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[tm_contact_form topic="Comedy ghostwriting"]
<!-- /wp:shortcode --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
